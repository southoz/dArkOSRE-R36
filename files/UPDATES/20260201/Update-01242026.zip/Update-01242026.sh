#!/bin/bash

CURRENT_DIR="$(dirname "$(realpath "$0")")"

if [ -f "/opt/system/Advanced/Switch to Main SD for Roms.sh" ]; then
    SDREMOVE="/opt/system/Advanced/Switch to SD2 for Roms.sh"
elif [ -f "/opt/system/Advanced/Switch to SD2 for Roms.sh" ]; then
    SDREMOVE="/opt/system/Advanced/Switch to Main SD for Roms.sh"
else
    SDREMOVE="None"
fi

sudo tar -xvf "$CURRENT_DIR/Update-01242026.tar.gz" -C / --no-same-owner 2>&1 | tee -a "$CURRENT_DIR/update.log" /dev/tty1
sudo chown ark:ark /etc/emulationstation/es_systems.cfg.*
sudo chmod 755 /etc/emulationstation/es_systems.cfg.*
sudo chown ark:ark "/opt/system/ZRam Manager.sh"
sudo chmod 755 "/opt/system/ZRam Manager.sh"
sudo chown ark:ark "/opt/system/Wifi Toggle.sh"
sudo chmod 755 "/opt/system/Wifi Toggle.sh"
sudo chown ark:ark "/opt/system/Advanced/Switch to SD2 for Roms.sh"
sudo chmod 755 "/opt/system/Advanced/Switch to SD2 for Roms.sh"
sudo chown ark:ark "/opt/system/Advanced/Switch to Main SD for Roms.sh"
sudo chmod 755 "/opt/system/Advanced/Switch to Main SD for Roms.sh"
sudo chown root:root "/usr/local/bin/Switch to SD2 for Roms.sh"
sudo chmod 777 "/usr/local/bin/Switch to SD2 for Roms.sh"

sudo rm "/boot/rk3326-rg351mp-linux.dtb" 2>&1 | tee -a "$CURRENT_DIR/update.log" /dev/tty1
if [ "$SDREMOVE" != "None" ]; then
    sudo rm "$SDREMOVE" 2>&1 | tee -a "$CURRENT_DIR/update.log" /dev/tty1
fi

if [ "$SDREMOVE" = "/opt/system/Advanced/Switch to SD2 for Roms.sh" ]; then
   sudo rm /etc/emulationstation/es_systems.cfg.roms 2>&1 | tee -a "$CURRENT_DIR/update.log" /dev/tty1
   sudo mv /etc/emulationstation/es_systems.cfg.roms2 /etc/emulationstation/es_systems.cfg 2>&1 | tee -a "$CURRENT_DIR/update.log" /dev/tty1
elif [ "$SDREMOVE" = "/opt/system/Advanced/Switch to Main SD for Roms.sh" ]; then
   sudo rm /etc/emulationstation/es_systems.cfg.roms2 2>&1 | tee -a "$CURRENT_DIR/update.log" /dev/tty1
   sudo mv /etc/emulationstation/es_systems.cfg.roms /etc/emulationstation/es_systems.cfg 2>&1 | tee -a "$CURRENT_DIR/update.log" /dev/tty1
elif [ "$SDREMOVE" = "None" ]; then
   sudo rm /etc/emulationstation/es_systems.cfg.roms2 2>&1 | tee -a "$CURRENT_DIR/update.log" /dev/tty1
   sudo mv /etc/emulationstation/es_systems.cfg.roms /etc/emulationstation/es_systems.cfg 2>&1 | tee -a "$CURRENT_DIR/update.log" /dev/tty1
fi
  
rm -rf "$CURRENT_DIR/Update-01242026.tar.gz" 2>&1 | tee -a "$CURRENT_DIR/update.log" /dev/tty1
rm -rf "$CURRENT_DIR/Update-01242026.sh" 2>&1 | tee -a "$CURRENT_DIR/update.log" /dev/tty1
sleep 5
sudo reboot 2>&1 | tee -a "$CURRENT_DIR/update.log" /dev/tty1
